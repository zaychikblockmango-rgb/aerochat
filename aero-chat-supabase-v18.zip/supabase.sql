-- Aero Chat → Supabase. Выполните целиком в SQL Editor (Run).
-- Приложение хранит всё дерево данных (users, u/<ник>/inbox, ch, groups, lists, media…)
-- в одной таблице kv: путь → JSON-значение. Таблицу messages приложение не использует.

create table if not exists public.kv (
  path       text primary key,
  value      jsonb,                       -- NULL = «удалено» (метка удаления)
  scope      text,                        -- 2-й сегмент пути: users / u / ch / groups / lists / media …
  uname      text,                        -- для sky/u/<ник>/… — ник (фильтр Realtime)
  updated_at timestamptz not null default now()
);
create index if not exists kv_path_c on public.kv ((path collate "C"));
create index if not exists kv_scope on public.kv (scope);
create index if not exists kv_uname on public.kv (uname);

create or replace function public.kv_meta() returns trigger language plpgsql as $$
begin
  new.scope := split_part(new.path,'/',2);
  new.uname := case when new.scope='u' then split_part(new.path,'/',3) end;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists kv_meta_t on public.kv;
create trigger kv_meta_t before insert or update on public.kv
  for each row execute function public.kv_meta();

-- чтение поддерева: сам путь и всё, что глубже
create or replace function public.kv_get(p text)
returns table(path text, value jsonb) language sql stable as $$
  select k.path, k.value from public.kv k
  where k.path = p
     or (k.path collate "C" >= p || '/' and k.path collate "C" < p || '0');
$$;

-- пакетная запись [{"p":"sky/…","v":<json|null>}, …]; запись в путь удаляет всё глубже него
create or replace function public.kv_write(rows jsonb) returns void language plpgsql as $$
declare r jsonb;
begin
  for r in select * from jsonb_array_elements(rows) loop
    delete from public.kv where path collate "C" >= (r->>'p') || '/' and path collate "C" < (r->>'p') || '0';
    insert into public.kv(path, value)
    values (r->>'p', case when jsonb_typeof(r->'v')='null' then null else r->'v' end)
    on conflict (path) do update set value = excluded.value;
  end loop;
end $$;

-- доступ для publishable (anon) ключа — аналог старых правил Firebase {".read":true,".write":true}
alter table public.kv enable row level security;
drop policy if exists kv_all on public.kv;
create policy kv_all on public.kv for all to anon, authenticated using (true) with check (true);
grant select, insert, update, delete on public.kv to anon, authenticated;
grant execute on function public.kv_get(text), public.kv_write(jsonb) to anon, authenticated;

-- Realtime
do $$ begin
  alter publication supabase_realtime add table public.kv;
exception when duplicate_object then null; end $$;
