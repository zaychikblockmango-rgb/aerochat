// Sky Chat — отправка push-уведомлений (Web Push + VAPID, без внешних библиотек)
// Переменные окружения Netlify: VAPID_PUBLIC, VAPID_PRIVATE, VAPID_SUBJECT (mailto:you@mail.com)
const crypto = require('crypto');
const SB = process.env.SUPABASE_URL || 'https://seeebkmtzxvayjvkuzln.supabase.co';
const KEY = process.env.SUPABASE_KEY || 'sb_publishable_0GTwikH-UOG5oVgs_YLG0g_qCoydoV9';
const OK_HOSTS = ['googleapis.com', 'mozilla.com', 'apple.com', 'windows.com'];
const b64u = b => Buffer.from(b).toString('base64url');
const ret = (s, b) => ({ statusCode: s, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b || {}) });

function vapid(aud) {
  const pub = Buffer.from(process.env.VAPID_PUBLIC, 'base64url');
  const key = crypto.createPrivateKey({ key: { kty: 'EC', crv: 'P-256', x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)), d: process.env.VAPID_PRIVATE }, format: 'jwk' });
  const h = b64u(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const p = b64u(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 43200, sub: process.env.VAPID_SUBJECT || 'mailto:admin@skychat.app' }));
  const sig = crypto.sign('sha256', Buffer.from(h + '.' + p), { key, dsaEncoding: 'ieee-p1363' });
  return h + '.' + p + '.' + b64u(sig);
}

exports.handler = async (e) => {
  if (e.httpMethod !== 'POST') return ret(405);
  let b; try { b = JSON.parse(e.body || '{}'); } catch (x) { return ret(400); }
  const { token, from, to } = b;
  if (![token, from, to].every(v => typeof v === 'string' && v.length > 0 && v.length < 3000) || from === to) return ret(400);
  if (!process.env.VAPID_PUBLIC || !process.env.VAPID_PRIVATE) return ret(500, { error: 'VAPID не настроен' });
  try {
    // Подписки получателя (Supabase RPC kv_get). Проверки Firebase-токена больше нет: вход теперь без Firebase Auth.
    const rr = await fetch(SB + '/rest/v1/rpc/kv_get', { method: 'POST', headers: { apikey: KEY, Authorization: 'Bearer ' + KEY, 'Content-Type': 'application/json' }, body: JSON.stringify({ p: 'sky/push/' + to }) });
    if (!rr.ok) return ret(502, { error: 'db ' + rr.status });
    const subs = {};
    for (const row of await rr.json()) { const k = row.path.split('/').pop(); if (row.value) subs[k] = row.value; }
    let sent = 0;
    for (const k of Object.keys(subs)) {
      const ep = subs[k] && subs[k].e; let u;
      try { u = new URL(ep); } catch (x) { continue; }
      if (u.protocol !== 'https:' || !OK_HOSTS.some(h => u.hostname === h || u.hostname.endsWith('.' + h))) continue;
      const r = await fetch(ep, { method: 'POST', headers: { Authorization: 'vapid t=' + vapid(u.origin) + ', k=' + process.env.VAPID_PUBLIC, TTL: '120', Urgency: 'high' } });
      if (r.ok) sent++;
    }
    return ret(200, { sent });
  } catch (x) { return ret(500, { error: String(x.message || x) }); }
};
