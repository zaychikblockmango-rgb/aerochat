Aero Chat — PWA-пакет

1. С компьютера откройте https://app.netlify.com/drop и перетащите сюда ЭТУ папку (распакованный архив).
2. Netlify даст https-ссылку. Откройте её на телефоне в Chrome.
3. После входа внизу появится плашка «Скачать приложение» — нажмите «Скачать» и подтвердите установку.

Подойдёт и любой другой https-хостинг (GitHub Pages, Cloudflare Pages).

БАЗА: Supabase. Перед первым запуском выполните supabase.sql в Supabase → SQL Editor → Run.
